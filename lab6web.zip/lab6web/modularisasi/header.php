<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Rental Mobil</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <header>
        <div class="logo">
            Admin Rental Mobil
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Daftar Mobil</a></li>
                <li><a href="tambah.php">Tambah Mobil</a></li>
            </ul>
        </nav>
    </header>